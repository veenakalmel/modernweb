const hobbiesArray = [
    {name : "Singing", lengthInYearsAtHobby : 25},
    {name :  "Dancing", lengthInYearsAtHobby : 20},
    {name : "Playing" , lengthInYearsAtHobby : 10}
]

function printHobby(a){
    console.log(`My first hobby is  ${a.name}  enjoyed for ${a.lengthInYearsAtHobby}`);

}


function returnHobbiesHTML() {
    let hobbyInfo = `
        <ul>
    `;
    hobbiesArray.forEach(hobby => {
        hobbyInfo+= `<li>${hobby.name} ${hobby.lengthInYearsAtHobby}</li>`;
        });
        hobbyInfo+=`</ul>`;
    return hobbyInfo;
}

printHobby(hobbiesArray[0]);