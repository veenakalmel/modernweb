function displayName(a){
 console.log("Hello "+ a);
}

displayName("Veena");

function covertToCelcius(temp){
    
}

function covertToFH(temp){
    

}