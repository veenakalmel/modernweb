let hobbies = ['Singing', 'Dancing', 'Playing'];

function printHobbies(h){
    if (hobbies.length == 3){        
        console.log("I like three things");
    }
    for (let index = 0 ; index < hobbies.length ; index ++ ){
        console.log("I like "+ hobbies[index]);
    }
}

printHobbies(hobbies);

let myColor = ["Red", "Green", "White", "Black"];

console.log(myColor.join());

