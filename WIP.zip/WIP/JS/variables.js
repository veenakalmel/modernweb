let x,y,z;
x=10;
y = '10';
z=30;
console.log(`x is ${typeof x}`);

var newX = x++;
console.log(newX);
console.log(x==newX);

let timeInMs = Date.now();

console.log(timeInMs);

const epochTime = new Date(0);

console.log(epochTime);

const birthday = // Date string method
new Date("January 31 1980 12:30");

console.log(birthday.getFullYear());
