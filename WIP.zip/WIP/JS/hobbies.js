const hobbiesArray = [
    {name : "Singing", lengthInYearsAtHobby : 25},
    {name :  "Dancing", lengthInYearsAtHobby : 20},
    {name : "Playing" , lengthInYearsAtHobby : 10}
]

function printHobby(a){
    console.log(`My first hobby is  ${a.name}  enjoyed for ${a.lengthInYearsAtHobby}`);

}

printHobby(hobbiesArray[0]);